// App structure using React and Tailwind CSS for Aakarshan Studio
// Theme updated to black and yellow, logo added + loyalty & referral tab

import { useState } from 'react';
import { Card, CardContent } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Textarea } from './components/ui/textarea';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './components/ui/tabs';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from './components/ui/select';
import { Label } from './components/ui/label';

const staff = ['Sahil (Hair)', 'Mamun (Female Beauty)', 'Mohini (Unisex)', 'Alisha (Mani-Pedi)', 'Siya (Pedi)'];
const services = [
  'Haircut',
  'Facial',
  'Hair Spa',
  'Manicure',
  'Pedicure',
  'Hair Color',
  'Hydra Facial',
  'Nail Art'
];

// simplified component
export default function App() {
  return <div>Hello Aakarshan</div>
}
